create view yyg_user_yg_group as
  select `a`.`ygProductId`                        AS `ygproductId`,
         `a`.`period`                             AS `period`,
         group_concat(`a`.`buyNos` separator ',') AS `buyNos`,
         sum(`a`.`buyNum`)                        AS `buyNum`,
         `a`.`createTime`                         AS `createTime`,
         `a`.`buyUserId`                          AS `buyUserId`,
         `b`.`status`                             AS `status`
  from (`yyyd`.`yyg_user_yg` `a` join `yyyd`.`yyg_yg_product` `b`)
  where ((`a`.`buyNos` <> 0) and (`a`.`ygProductId` = `b`.`id`) and (`b`.`deleteStatus` = 0))
  group by `a`.`period`, `a`.`ygProductId`, `a`.`buyUserId`;

